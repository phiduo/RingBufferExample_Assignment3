# Submission Notes

## Assignment Part A: Code Coverage

### Regarding the reports
Since there are multiple reports, we weren't sure which ones 
you wanted us to include for Part A, so we included the entire 
target folder before and after adding more tests, and marked 
them as "coverage_before" and "coverage_after" just to be sure.

### Regarding configuring the coverage measurement
As far as we could tell, tests have already been automatically
excluded from the coverage tests, so no configuration was needed.